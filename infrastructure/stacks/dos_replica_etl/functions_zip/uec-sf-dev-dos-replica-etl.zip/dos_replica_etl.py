from __future__ import print_function
import boto3
import base64
from botocore.exceptions import ClientError
import psycopg2
import psycopg2.extras
import os
import json
from requests_aws4auth import AWS4Auth
from elasticsearch import Elasticsearch, RequestsHttpConnection, helpers

USR = os.environ.get("USR")
SOURCE_DB = os.environ.get("SOURCE_DB")
ENDPOINT = os.environ.get("ENDPOINT").split(":")[0]
PORT = os.environ.get("PORT")
REGION = os.environ.get("REGION")
SECRET_NAME = os.environ.get("SECRET_NAME")
SECRET_KEY = os.environ.get("SECRET_KEY")
ES_DOMAIN_ENDPOINT = os.environ.get("ES_DOMAIN_ENDPOINT")



def get_secret():

    secret_name = SECRET_NAME
    region_name = "eu-west-2"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=region_name)

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        if e.response["Error"]["Code"] == "DecryptionFailureException":
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response["Error"]["Code"] == "InternalServiceErrorException":
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response["Error"]["Code"] == "InvalidParameterException":
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response["Error"]["Code"] == "InvalidRequestException":
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response["Error"]["Code"] == "ResourceNotFoundException":
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if "SecretString" in get_secret_value_response:
            return get_secret_value_response["SecretString"]
        else:
            return base64.b64decode(get_secret_value_response["SecretBinary"])


# Method to connect to database
def connect():
    try:
        secret_dict = json.loads(get_secret())
        conn = psycopg2.connect(
            host=ENDPOINT,
            port=PORT,
            user=USR,
            database=SOURCE_DB,
            password=secret_dict[SECRET_KEY],
        )
        return conn
    except Exception as e:
        print("Database connection failed due to {}".format(e))
        raise e


# Method to get cursor from db
def getCursor(conn):
    try:
        cur = conn.cursor()
        return cur
    except Exception as e:
        print("unable to retrieve cursor due to {}".format(e))
        conn.close()
        raise e


# Method to extract postcodes from db
def dos_replica_etl():

    selectStatement = """select
                            s.id,
                            s.uid,
                            s.name,
                            s.publicname,
                            s.typeid,
                            t.name as servicetype,
                            s.address,
                            s.postcode,
                            r.name as referralrole,
                            c.color as capacitystatus,
                            s.easting,
                            s.northing,
                            s.publicphone,
                            s.nonpublicphone,
                            s.email,
                            s.web,
                            s.publicreferralinstructions,
                            s.telephonetriagereferralinstructions,
                            s.odscode,
                            s.isnational,
                            s.modifiedtime
                        from
                            pathwaysdos.services s,
                            pathwaysdos.servicecapacities sc,
                            pathwaysdos.capacitystatuses c,
                            pathwaysdos.servicereferralroles sr,
                            pathwaysdos.referralroles r,
                            pathwaysdos.servicetypes t
                        where (
                            s.id = sc.serviceid
                            and
                            sc.capacitystatusid = c.capacitystatusid
                            and
                            sr.serviceid = s.id
                            and
                            sr.referralroleid = r.id
                            and
                            s.typeid = t.id
                        );"""

    print("Open connection")
    conn = connect()
    print("Connection opened")
    cur = getCursor(conn)
    try:
        cur.execute(selectStatement)
        records = cur.fetchall()
        count = len(records)
        print("Successfully fetched " + str(count) + " records")
        resp = insert_records_to_elasticsearch(records)
        return resp
    except Exception as e:
        print("DoS Read Replica ETL extraction failed due to {}".format(e))
    finally:
        cur.close()
        conn.close()
        print("PostgreSQL connection is closed")


def connect_to_elastic_search():
    try:
        print("ES DOMAIN: " + ES_DOMAIN_ENDPOINT)
        host = ES_DOMAIN_ENDPOINT # The domain with https:// and trailing slash. For example, https://my-test-domain.us-east-1.es.amazonaws.com/
        region = REGION # For example, us-west-1

        print("getting credentials")
        service = 'es'
        credentials = boto3.Session().get_credentials()
        awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

        print("connecting to es")
        es = Elasticsearch(
            hosts = [{'host': host, 'port': 443}],
            http_auth = awsauth,
            use_ssl = True,
            verify_certs = True,
            connection_class = RequestsHttpConnection
        )
        print("connected to es")
        return es;
    except Exception as e:
        print("Unable to connect to ElasticSearch due to {}".format(e))


def insert_records_to_elasticsearch(query_results):

    es = connect_to_elastic_search()
    doc_list = []
    for row in query_results:
        document = {
            "id": row[0],
            "u_id": row[1],
            "name": row[2],
            "public_name": row[3],
            "type_id": row[4],
            "type": row[5],
            "address": row[6],
            "postcode": row[7],
            "referral_roles": row[8],
            "capacity_status": row[9],
            "easting": row[10],
            "northing": row[11],
            "public_phone_number": row[12],
            "non_public_phone_number": row[13],
            "email": row[14],
            "web": row[15],
            "public_referral_instructions": row[16],
            "referral_instructions": row[17],
            "ods_code": row[18],
            "is_national": row[19],
            "updated": row[20]
        }
        doc_list.append(document)
    print("size of import: " + str(len(doc_list)))
    try:
        print("Inserting into ES...")
        resp = helpers.bulk(es, doc_list, index = "service", doc_type = "_doc")
        print("Insert complete")
        return resp
    except Exception as e:
        print("Unable to insert records due to {}".format(e))


# This is the entry point for the Lambda function
def lambda_handler(event, context):

    print("Starting DoS ETL")
    resp = dos_replica_etl()
    return resp
